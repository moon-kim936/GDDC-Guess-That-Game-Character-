extends RichTextLabel


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	for i in Global.scores.size():
		append_text(Global.names[i] + "\n")


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
