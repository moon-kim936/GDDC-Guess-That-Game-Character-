extends Node

@export var current_chara : Sprite2D
@export var count_correct : Label
@export var confirm : Sprite2D
@export var nextskip : Button
@export var timer_text : Label

@onready var line_edit = $CanvasLayer/ColorRect/VBoxContainer/HBoxContainer/MarginContainer/ColorRect/LineEdit
@onready var timer = $TotalTimer

var current_state
var current_chara_name
var num_right
var num_wrong
var guessed = false

enum State{
	PRE,
	RUNNING,
	FINISHED
}

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	num_right = 0
	num_wrong = 0
	confirm.texture = null
	change_state(State.RUNNING)

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	match current_state:
		State.PRE:
			pass
		State.RUNNING:
			if guessed == true:
				if Input.is_action_just_pressed("enter"):
					change_chara()
			timer_text.text = str(int(timer.get_time_left()))
		State.FINISHED:
			pass

func change_chara():
	guessed = false
	
	nextskip.text = "SKIP"
	
	confirm.texture = null
	
	line_edit.editable = true
	line_edit.clear()
	
	#print("Changing character")
	var files: PackedStringArray = DirAccess.get_files_at("res://sprites/")
	var random_file_name: String = files.get(randi_range(1, files.size()-1))
	print(random_file_name)
	if random_file_name.right(7) == ".import":
		random_file_name = random_file_name.left(random_file_name.length() - 7)
	current_chara_name = random_file_name.left(random_file_name.length() - 4)
	var path_name = "res://sprites/" + random_file_name
	#print(path_name)
	current_chara.texture = load(path_name)
	
	current_chara.modulate = Color(0, 0 ,0)

func change_state(next_state):
	current_state = next_state
	match current_state:
		State.PRE:
			print("Changing to PRE")
		State.RUNNING:
			change_chara()
			timer.start()
			line_edit.edit()
			print("Changing to RUNNING")
			pass
		State.FINISHED:
			timer.stop()
			Global.set_new_score(num_right)
			Global.set_new_error(num_wrong)
			Global.add_pair(Global.username, num_right)
			get_tree().change_scene_to_file("res://scenes/end_screen.tscn")
			print("Changing to FINISHED")
			pass

func _on_line_edit_text_submitted(new_text: String) -> void:
	if new_text.to_lower() == current_chara_name and guessed == false:
		num_right = num_right + 1
		count_correct.text = str(num_right)
		confirm.texture = load("res://other_sprites/check.png")
		line_edit.editable = false
		nextskip.text = "NEXT"
		current_chara.modulate = Color(1.0, 1.0, 1.0, 1.0)
		await get_tree().create_timer(0.1).timeout
		guessed = true
	elif new_text.to_lower() != current_chara_name and guessed == false:
		confirm.texture = load("res://other_sprites/cross.png")
		num_wrong = num_wrong + 1
		line_edit.clear()

func _on_next_skip_button_down() -> void:
	num_wrong = num_wrong + 1
	change_chara()

func _on_total_timer_timeout() -> void:
	change_state(State.FINISHED)
