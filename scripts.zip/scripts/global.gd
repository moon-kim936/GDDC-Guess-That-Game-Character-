extends Node

var names : Array[String]
var scores : Array[int]

var username
var newest_score
var newest_errors

var max_array_size = 18

func _ready() -> void:
	names = [
		#"Alpha",
		#"Bravo",
		#"Charlie",
		#"Diego",
		#"Echo",
		#"Foxtrot",
		#"George",
		#"Henry",
		#"Indigo",
		#"Jolly",
		#"Kindred",
		#"Lingo",
		#"Money",
		#"Nelly",
		#"Onion",
		#"Phoenix",
		#"Quarter"
	]
	
	scores = [
		#20,
		#19,
		#18,
		#17,
		#16,
		#15,
		#14,
		#13,
		#12,
		#11,
		#10,
		#9,
		#8,
		#7,
		#6,
		#5,
		#4
	]

func set_user(u):
	username = u

func set_new_score(n):
	newest_score = n

func set_new_error(e):
	newest_errors = e

func add_pair(name, score):
	if scores.size() == 0:
		names.append(name)
		scores.append(score)
		return
	elif scores.size() < max_array_size:
		scores.append(score)
		names.append(name)
		if scores[scores.size()-2] >= scores[scores.size()-1]:
			return
		var temp_s = 0
		var temp_n = ""
		var i = scores.size()-1
		while scores[i-1] < scores[i] and i > 0:
			temp_s = scores[i-1]
			temp_n = names[i-1]
			scores[i-1] = scores[i]
			names[i-1] = names[i]
			scores[i] = temp_s
			names[i] = temp_n
			i = i - 1
	elif scores.size() == max_array_size:
		if score < scores[scores.size()-1]:
			return
		else:
			var temp_s = 0
			var temp_n = ""
			var i = scores.size()-1
			scores[i] = score
			names[i] = name
			while scores[i-1] < scores[i] and i > 0:
				temp_s = scores[i-1]
				temp_n = names[i-1]
				scores[i-1] = scores[i]
				names[i-1] = names[i]
				scores[i] = temp_s
				names[i] = temp_n
				i = i - 1
