extends Node2D

@onready var name_input = $CanvasLayer/MarginContainer/VBoxContainer/MarginContainer2/LineEdit

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.

func _on_line_edit_text_submitted(new_text: String) -> void:
	Global.set_user(new_text)
	name_input.clear()
	get_tree().change_scene_to_file("res://scenes/main.tscn")
