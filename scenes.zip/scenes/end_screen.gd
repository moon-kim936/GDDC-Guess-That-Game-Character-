extends Node2D

@export var next : Button
@export var stats : Label

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	stats.text = "User: " + Global.username + "\n" + "Score: " + str(Global.newest_score) + "\n" + "# Wrong / Skipped: " + str(Global.newest_errors)

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func _on_button_button_down() -> void:
	get_tree().change_scene_to_file("res://scenes/start_screen.tscn")
